
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-CFClock',
  templateUrl: 'CFClock.component.html',
})
export class CFClockComponent  {
  @Input() props: any;
}
